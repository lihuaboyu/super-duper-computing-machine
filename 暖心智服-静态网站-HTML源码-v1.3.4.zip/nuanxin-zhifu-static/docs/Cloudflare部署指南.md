# 暖心智服网站 · Cloudflare Pages 部署指南（零基础）

> 适用：把已经做好的静态网站（HTML 源码）发布到互联网，得到一个 `https://xxx.pages.dev` 的公开网址。
> 需要的两个平台：**GitHub（放代码）**、**Cloudflare（生成网站）**，都免费。
> 不需要买服务器、不需要装软件、不需要写代码。

---

## 一、你需要准备的东西（前置条件）

| 东西 | 说明 | 你的状态 |
| --- | --- | --- |
| GitHub 账号 | 免费注册：<https://github.com> | 已有（用户名 Lihuaboyu） |
| Cloudflare 账号 | 免费注册：<https://dash.cloudflare.com> | 已有 |
| 浏览器 | 用电脑版 Chrome / Edge，不要用手机操作 | — |
| 部署文件 | 本压缩包内的 **`nuanxin-zhifu` 文件夹**（index.html 等在里面） | 已备好 |
| 费用 | 0 元。GitHub 免费、Cloudflare Pages 免费（流量够用） | — |

**不需要**：域名（先送一个 `xxx.pages.dev`）、服务器、数据库、AI 密钥（试点版问答是本地知识库）。

---

## 二、方案 A：GitHub + Cloudflare 联动（推荐，以后改文件自动更新）

### 第 1 步：在 GitHub 建一个仓库

1. 打开 <https://github.com> 并登录。
2. 右上角 **+** → **New repository（新建仓库）**。
3. 建议：
   - Repository name（仓库名）：`nuanxin-zhifu`
   - 选 **Public（公开）**（Cloudflare 免费版需要公开仓库；网站源码本来就是公开的）。
   - 其他都不勾，点 **Create repository**。

### 第 2 步：把网站文件传进仓库

1. 进入刚建的空仓库，点击蓝色文字 **"uploading an existing file"**（上传已有文件）。
2. 解压本部署包，打开里面的 **`nuanxin-zhifu` 文件夹**，全选里面的内容
   （`index.html`、`404.html`、`ai.html`、`apply.html`、`about.html`、`local.html`、`health.html`、
   `track.html`、`feedback.html`、`privacy.html`、`terms.html`、`assets`、`admin`、`_headers`、`robots.txt` 等），
   **一起拖到网页上传区**。
   - 注意：拖的是文件夹**里面的内容**，不是把 `nuanxin-zhifu` 外层文件夹拖进去。
   - 确认 `index.html` 在仓库的第一层（根目录），不要多一层文件夹。
3. 页面下方点 **Commit changes（提交更改）**，等上传完成。

### 第 3 步：在 Cloudflare 连接 GitHub

1. 打开 <https://dash.cloudflare.com> 并登录。
2. 左侧菜单点 **Workers & Pages** → 点 **Create（创建）** → 选 **Pages（页面）** 标签 → **Connect to Git（连接 Git）**。
3. 第一次使用会让你授权 GitHub：点 **Connect GitHub / 授权**，选择你自己的账号，
   选 **Only select repositories（仅选择指定仓库）**，勾选 `nuanxin-zhifu`，保存授权。
4. 回到 Cloudflare，选中 `nuanxin-zhifu` 仓库，点 **Begin setup（开始设置）**。

### 第 4 步：构建设置（这页最关键，照抄）

| 选项 | 填什么 |
| --- | --- |
| Project name（项目名） | `nuanxin-zhifu`（只能小写字母、数字、短横线） |
| Production branch（生产分支） | `main` |
| Framework preset（框架预设） | **None（无）** |
| Build command（构建命令） | **留空，什么都不填** |
| Build output directory（输出目录） | 填 `/`（一个斜杠；或留空） |

其他一律不动，点 **Save and Deploy（保存并部署）**。

### 第 5 步：拿到网址

1. 等待 1–2 分钟，状态变成 **Success**。
2. 页面上会显示网址，形如：
   **`https://nuanxin-zhifu.pages.dev`**
3. 点开这个网址，网站就上线了。后台地址是 `https://你的域名/admin/`。

### 以后怎么更新网站？

把修改过的文件重新在 GitHub 网页上传、覆盖同名文件并 Commit，
Cloudflare 会在 1–2 分钟内自动重新部署，不用做任何操作。

---

## 三、方案 B：Cloudflare 直接拖拽（最快，不经过 GitHub）

1. 打开 <https://dash.cloudflare.com> → **Workers & Pages** → **Create** → **Pages** 标签 → **Upload assets（上传资源）**。
2. Project name 填 `nuanxin-zhifu`，点 **Create project**。
3. 把本部署包里 **`nuanxin-zhifu` 文件夹里面的全部内容**拖到上传区（或直接拖该文件夹）。
4. 点 **Deploy site（部署网站）**，等 1 分钟，拿到 `https://nuanxin-zhifu.pages.dev`。
5. 缺点：每次更新网站都要重新拖拽上传；方案 A 更新更省事。

---

## 四、部署后逐项检查（照着点一遍）

1. 手机和电脑都能打开网址，首页、导航 7 个菜单都能跳转。
2. 切换手机视图（浏览器按 F12 → 手机图标），排版正常。
3. AI 助手能回答残疾人补贴类问题，答不出的会提示拨打 12345。
4. 公益帮扶申请能提交并显示服务编号；试点版提示语清楚（数据只存浏览器）。
5. 后台 `/admin/` 能打开，用内置账号登录（账号见压缩包内 `docs/README.md`）。
6. 打开 `https://你的域名/不存在的页面` 会显示 404 页。
7. 点浏览器地址栏小锁，确认是 **https://**（Cloudflare 自动提供）。

---

## 五、重要提醒（务必知道）

1. **`pages.dev` 域名在中国大陆的访问速度和稳定性不保证**（Cloudflare 在大陆没有节点），
   用于答辩演示、老师评审、团队内部完全够用；如果要正式对哈密居民长期提供服务，
   建议后续购买**国内服务器（阿里云/腾讯云学生机）+ 域名 + ICP 备案**。
2. 本平台是**静态试点版**：居民在线提交的申请只保存在他自己的手机/电脑浏览器里，
   工作人员后台**看不到**。页面上已如实提示居民急需帮扶请拨 12345 或联系社区。
   要实现"居民在线提交、工作人员后台真实收到"，需要部署 Node 后端版本（随项目有全栈源码，
   部署需要服务器，可后续再做）。
3. **后台内置账号密码（admin/Admin@12345 等）是公开的测试密码**，仅用于试点演示；
   正式上线必须换成后端真实登录，不能用这套静态后台处理真实居民信息。
4. 上线前继续补齐：项目办公电话、盖章证明扫描件、6 张照片的肖像授权、
   真实志愿者名单与培训记录、科普文章的专业教师审核。
5. 网站不得使用国徽、国旗等国家机关标志（已在源码中遵守《国徽法》）。
