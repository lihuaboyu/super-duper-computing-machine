# -*- coding: utf-8 -*-
"""检查静态 HTML 中可能无行为的按钮：无 id、无 onclick、非 submit 的 button。"""
import io, os, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
found = 0
for dp, _, fs in os.walk(ROOT):
    if '_shots' in dp:
        continue
    for f in fs:
        if not f.endswith('.html'):
            continue
        p = os.path.join(dp, f)
        s = io.open(p, encoding='utf-8').read()
        for m in re.finditer(r'<button\b[^>]*>', s):
            t = m.group(0)
            if 'id=' not in t and 'onclick=' not in t and 'type="submit"' not in t:
                print(os.path.relpath(p, ROOT), '::', t[:140])
                found += 1
print('检查完成，疑似无行为按钮: %d' % found)
