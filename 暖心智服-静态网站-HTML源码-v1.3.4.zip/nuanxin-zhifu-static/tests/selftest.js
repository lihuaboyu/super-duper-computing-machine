/* ============================================================
   暖心智服 · 静态网站  数据层与业务流程自测脚本
   运行方式（在项目根目录）：  node tests/selftest.js
   不依赖任何第三方库：用内存版 localStorage/sessionStorage 模拟浏览器，
   加载 assets/js 下的 config/data/store/qa，跑通完整业务闭环。
   ============================================================ */
'use strict';
const fs = require('fs');
const path = require('path');

/* ---------- 浏览器环境模拟 ---------- */
function memoryStorage() {
  const m = {};
  return {
    getItem: k => (Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null),
    setItem: (k, v) => { m[k] = String(v); },
    removeItem: k => { delete m[k]; },
    clear: () => { Object.keys(m).forEach(k => delete m[k]); }
  };
}
const store = memoryStorage();
const session = memoryStorage();
global.window = {
  SITE_CONFIG: null, CONSTANTS: null, SEED_DATA: null,
  localStorage: store, sessionStorage: session
};
global.localStorage = store;
global.sessionStorage = session;
global.console = console;

const jsDir = path.join(__dirname, '..', 'assets', 'js');
['config.js', 'data.js', 'store.js', 'qa.js'].forEach(f => {
  const code = fs.readFileSync(path.join(jsDir, f), 'utf8');
  // eslint-disable-next-line no-new-func
  new Function('window', 'localStorage', 'sessionStorage', code)(
    global.window, store, session
  );
});
// 浏览器里 window.Store 即全局 Store；Node 模拟环境需显式挂到 global
global.Store = window.Store;
global.QA = window.QA;
const Store = window.Store;
const QA = window.QA;
const C = window.CONSTANTS;

/* ---------- 极简断言 ---------- */
let pass = 0, fail = 0;
function ok(cond, name) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name); }
}
function eq(a, b, name) { ok(a === b, name + '（实际：' + a + '，期望：' + b + '）'); }

Store.init();

console.log('\n[1] 种子数据与审核状态');
eq(Store.knowledgeList(true).length, 14, '知识库共 14 条（含 K007/K008 草稿，K009—K014 为2026-10-22新增核实政策）');
eq(Store.knowledgeList(false).length, 12, '已审核知识库 12 条（K007/K008 草稿不进问答）');
eq(Store.localList(true).length, 9, '便民信息共 9 条（v1.3.2 起全部为已核实真实信息）');
eq(Store.localList(false).length, 9, '已核实便民信息 9 条（无演示数据）');
ok(Store.localList(true).every(function (l) { return l.status === 'verified'; }), '便民信息无演示数据残留（L004/L005 已替换为 12385/12338，L009 为试点社区）');
ok(Store.articleList(false).length === 0, '科普文章全部待审核，正式列表为 0 条');

console.log('\n[2] AI 问答：急症拦截');
ok(QA.ask('我爸爸突然胸痛、说话不清').emergency, '胸痛+言语不清触发急症转介');
ok(QA.ask('我不想活了，想结束生命').emergency, '自伤高危词触发心理危机转介');
ok(QA.ask('孩子被打了，被虐待怎么办').emergency, '儿童伤害触发报警转介');

console.log('\n[3] AI 问答：知识库检索与无依据兜底');
const r1 = QA.ask('想申请公益帮扶应该怎么做？');
ok(r1.matched && r1.items.length > 0, '公益帮扶申请问题命中知识库');
ok(r1.items.every(i => i.status === 'approved'), '命中条目全部是已审核状态');
const r2 = QA.ask('今天天气怎么样？');
eq(r2.matched, false, '无关问题不编造、不命中');
const r3 = QA.ask('补贴每个月多少钱？');
ok(Store.knowledgeList(false).every(i => /140/.test(i.content) === false), '已审核库中不含未核实的金额数字');

console.log('\n[4] 申请表单校验');
const bad = Store.createApplication({ type: '', region: '', phone: '', need: '' });
eq(bad.ok, false, '空表单提交被拒绝');
const childNoGuardian = Store.createApplication({
  type: 'left_behind_child', region: '哈密市', phone: '13800000000', need: '孩子需要课业陪伴', authConsent: true
});
eq(childNoGuardian.ok, false, '儿童服务未勾选监护人同意被拒绝');
const noAuth = Store.createApplication({
  type: 'daily_care', region: '哈密市', phone: '13800000000', need: '老人卧床需要协助'
});
eq(noAuth.ok, false, '未勾选授权确认被拒绝');
const badPhone = Store.createApplication({
  type: 'daily_care', region: '哈密市', phone: 'abc', need: '需求描述', authConsent: true
});
eq(badPhone.ok, false, '非法手机号被拒绝');

const created = Store.createApplication({
  type: 'left_behind_child', region: '哈密市', regionDetail: '伊州区某街道',
  need: '留守儿童，需要每周课业陪伴', contactName: '古丽女士', phone: '13900001111',
  contactTime: '工作日下午', guardianName: '监护人：艾先生', guardianConsent: true, authConsent: true
});
ok(created.ok && /^NXF-\d{8}-\d{4}$/.test(created.code), '合法申请创建成功，编号格式 NXF-日期-4位');
const code = created.code;
const appId = created.app.id;

console.log('\n[5] 进度查询双验证');
ok(!Store.findByCodeAndPhone(code, '13000000000'), '错误手机号查不到申请');
ok(Store.findByCodeAndPhone(code, '13900001111'), '正确编号+手机号可查询');
ok(Store.findByCodeAndPhone(code.toLowerCase(), '13900001111'), '编号大小写不敏感');

console.log('\n[6] 登录与角色权限');
eq(Store.login('admin', 'wrong').ok, false, '错误密码拒绝登录');
const staffLogin = Store.login('staff', 'Staff@12345');
ok(staffLogin.ok, 'staff 登录成功');
eq(Store.requireRole(['admin']), false, 'staff 不能越权访问管理员功能');
ok(Store.requireRole(['staff', 'manager']), 'staff 可访问本职模块');
Store.login('admin', 'Admin@12345');
ok(Store.requireRole(['admin']), 'admin 可访问全部模块');

console.log('\n[7] 服务工单全流程（8 状态闭环）');
const jump = Store.setApplicationStatus(appId, 'closed');
eq(jump.ok, false, '非法跳状态（待审核→已结案）被拒绝');
ok(Store.setApplicationStatus(appId, 'contacting').ok, '待审核 → 联系中');
ok(Store.addContactLog(appId, '电话已联系，确认需求属实').ok, '记录联系情况');
ok(Store.setApplicationStatus(appId, 'planning').ok, '联系中 → 待安排');
const rejectNoReason = Store.setApplicationStatus(
  Store.applicationList()[0].id, 'rejected', {}
);
// 对另一张申请做必填原因校验更稳妥，这里直接复用当前申请
const order = Store.createOrder(appId, '张志愿者', '2026-10-25 上午');
ok(order.ok && order.order.code.indexOf('GD-') === 0, '创建工单并派单，状态=已安排');
eq(Store.getApplication(appId).status, 'arranged', '工单创建后申请同步为已安排');
const rec = Store.addOrderRecord(order.order.id, '已完成第一次上门课业陪伴 2 小时');
ok(rec.ok, '填写服务记录，状态=服务中');
eq(Store.getApplication(appId).status, 'serving', '服务记录后申请同步为服务中');
const fu = Store.addFollowup(code, '电话回访', '满意', '家属反馈孩子愿意继续');
ok(fu.ok, '登记回访，状态=待回访');
eq(Store.getApplication(appId).status, 'followup', '回访后申请同步为待回访');
const closed = Store.closeCase(code, '本学期陪伴 8 次，家庭满意，结案');
ok(closed.ok, '结案成功');
eq(Store.getApplication(appId).status, 'closed', '申请最终状态=已结案');
eq(Store.orderList()[0].status, 'closed', '工单同步结案');

console.log('\n[8] 暂无法处理必须填写原因');
const r2app = Store.createApplication({
  type: 'daily_care', region: '乌鲁木齐市', phone: '13700002222',
  need: '需要助浴服务', authConsent: true
});
ok(r2app.ok, '第二张申请创建成功');
ok(Store.setApplicationStatus(r2app.app.id, 'contacting').ok, '第二张：联系中');
ok(Store.setApplicationStatus(r2app.app.id, 'planning').ok, '第二张：待安排');
eq(Store.setApplicationStatus(r2app.app.id, 'rejected', {}).ok, false, '无原因的暂无法处理被拒绝');
ok(Store.setApplicationStatus(r2app.app.id, 'rejected', { reason: '服务范围外，已转介当地残联' }).ok, '有原因+转介后可暂无法处理');
eq(Store.getApplication(r2app.app.id).status, 'rejected', '状态=暂无法处理');

console.log('\n[9] 反馈、投诉、问答日志与统计');
eq(Store.addFeedback('答案纠错', '太短').ok, false, '少于 5 字的反馈被拒绝');
ok(Store.addFeedback('答案纠错', '这一条政策的电话好像不对').ok, '有效反馈保存成功');
ok(Store.addComplaint({ appCode: code, channel: '电话', content: '志愿者迟到一次' }).ok, '投诉登记成功');
const st = Store.stats();
eq(st.total, 2, '统计·申请总数 2（与实际记录一致）');
eq(st.closed, 1, '统计·已结案 1');
eq(st.rejected, 1, '统计·暂无法处理 1');
ok(Store.qaLogs().length >= 6, '问答匿名日志已记录');
ok(Store.auditLogs().length >= 3, '操作日志有记录');

console.log('\n[10] 二期：志愿者 / 培训 / 排班 / 提醒 / 统计');
// 种子成员（真实成员，非演示化名）
const vols0 = Store.volunteerList();
ok(vols0.length >= 2 && vols0.every(function (v) { return v.demo === false; }), '种子成员为真实成员，无演示化名、无演示标记');
eq(Store.volunteerSave({ name: '   ' }).ok, false, '志愿者无称呼被拒绝');
const nv = Store.volunteerSave({
  name: '测试同学（化名）', kind: 'student', major: 'nursing',
  bilingual: true, trained: true, status: 'active', region: '哈密市'
});
ok(nv.ok, '新增志愿者成功');
// 培训
eq(Store.trainingSave({ title: '' }).ok, false, '培训无主题被拒绝');
const nt = Store.trainingSave({ title: '测试培训', type: 'induction', date: '', hours: 3, status: 'planned' });
ok(nt.ok, '新增培训成功');
ok(Store.trainingSetStatus(nt.item.id, 'done'), '培训标记完成');
// 排班：校验、完成、时长累加、防重复
eq(Store.scheduleCreate({ date: '', volunteerName: '测试同学（化名）' }).ok, false, '排班无日期被拒绝');
eq(Store.scheduleCreate({ date: '2026-10-30', volunteerName: '' }).ok, false, '排班无志愿者被拒绝');
const nsc = Store.scheduleCreate({
  date: '2026-10-30', slot: '上午', volunteerName: '测试同学（化名）',
  serviceType: 'home_care', hours: 2, note: '测试排班'
});
ok(nsc.ok, '新增排班成功');
const hoursBefore = Store.volunteerList().find(function (v) { return v.id === nv.item.id; }).serviceHours;
Store.scheduleUpdate(nsc.item.id, { status: 'done' });
const hoursAfter = Store.volunteerList().find(function (v) { return v.id === nv.item.id; }).serviceHours;
eq(hoursAfter - hoursBefore, 2, '排班完成后服务时长 +2 小时');
Store.scheduleUpdate(nsc.item.id, { status: 'done' });
const hoursAfter2 = Store.volunteerList().find(function (v) { return v.id === nv.item.id; }).serviceHours;
eq(hoursAfter2, hoursAfter, '重复完成不会重复累加时长');
// 提醒
eq(Store.reminderCreate({ dueDate: '', content: 'x' }).ok, false, '提醒无日期被拒绝');
eq(Store.reminderCreate({ dueDate: '2026-10-25', content: '  ' }).ok, false, '提醒无内容被拒绝');
const nr = Store.reminderCreate({ appCode: code, dueDate: '2026-10-25', content: '电话回访测试' });
ok(nr.ok, '新增提醒成功');
ok(Store.reminderList().some(function (r) { return r.id === nr.item.id; }), '提醒列表包含新提醒');
ok(Store.reminderDone(nr.item.id).ok, '提醒标记完成');
// 问答质量统计：急症单列、命中率、未命中聚合
const emBefore = Store.qaStats().emergency;
const er = QA.ask('胸痛 呼吸困难 快不行了');
ok(er.emergency, '急症问题仍触发安全转介');
const noAns = QA.ask('附近宠物医院在哪里？');
ok(!noAns.matches, '知识库范围外问题仍不编造');
const qa = Store.qaStats();
eq(qa.emergency - emBefore, 1, '急症转介单独计入（增量 +1）');
ok(qa.unmatched >= 2, '两个无依据问题计入未命中（天气 + 宠物医院）');
ok(qa.hitRate !== null && qa.hitRate >= 0 && qa.hitRate <= 100, '命中率在 0-100 之间');
ok(qa.topUnmatched.length >= 1, '高频未命中问题有聚合');
// 统计报表
const rp = Store.reportData();
eq(rp.months.length, 6, '报表覆盖近 6 个月');
eq(Object.keys(rp.byType).length, 7, '按 7 类服务类型统计');
ok(rp.volunteers.active >= 1, '在岗志愿者统计有效');
ok(rp.schedules.done >= 1, '已完成排班统计有效');

console.log('\n[11] 重置本地数据');
Store.resetDemo();
eq(Store.applicationList().length, 0, '重置后申请归零');
eq(Store.knowledgeList(true).length, 14, '重置后种子知识库恢复');
eq(Store.volunteerList().length, 2, '重置后真实成员记录恢复');
eq(Store.trainingList().length, 0, '重置后培训记录为空（真实培训由后台据实录入，不预置演示记录）');
eq(Store.scheduleList().length, 0, '重置后排班记录归零');
eq(Store.reminderList().filter(function (r) { return r.kind === 'manual'; }).length, 0, '重置后人工提醒归零');

console.log('\n================ 自测结果 ================');
console.log('通过 ' + pass + ' 项，失败 ' + fail + ' 项');
if (fail > 0) { console.log('存在失败项，请检查 assets/js/store.js 与 qa.js。'); process.exit(1); }
console.log('全部通过 ✓');
