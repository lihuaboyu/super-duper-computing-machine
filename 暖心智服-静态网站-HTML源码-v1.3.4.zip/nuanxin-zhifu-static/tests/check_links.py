# -*- coding: utf-8 -*-
"""检查所有 HTML 中的内部链接/资源是否存在，是否存在僵尸按钮（href="#" 等）。"""
import io, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
problems = []
html_files = []
for dirpath, dirs, files in os.walk(ROOT):
    if '_shots' in dirpath or os.sep + 'docs' in dirpath:
        continue
    for f in files:
        if f.endswith('.html'):
            html_files.append(os.path.join(dirpath, f))

for hp in html_files:
    s = io.open(hp, encoding='utf-8').read()
    rel = os.path.dirname(hp)
    # 僵尸链接
    for m in re.finditer(r'href\s*=\s*["\']([^"\']*)["\']', s):
        href = m.group(1)
        if href in ('#', 'javascript:void(0)', 'javascript:;', 'javascript:void(0);'):
            problems.append((hp, '僵尸链接: ' + href))
        elif href.startswith(('http://', 'https://', 'mailto:', 'tel:', 'data:', '#')):
            continue
        else:
            target = href.split('#')[0].split('?')[0]
            if target:
                p = os.path.normpath(os.path.join(rel, target))
                if not os.path.exists(p):
                    problems.append((hp, '内部链接不存在: ' + href))
    # 资源引用
    for m in re.finditer(r'(?:src|href)\s*=\s*["\']([^"\']*assets/[^"\']*)["\']', s):
        p = os.path.normpath(os.path.join(rel, m.group(1)))
        if not os.path.exists(p):
            problems.append((hp, '资源不存在: ' + m.group(1)))
    # 无 href 的 <a> 且无 onclick（排除 <article>/<address> 等标签）
    for m in re.finditer(r'<a(?:\s[^>]*?)?>(?![^<]*</a>)', s):
        tag = m.group(0)
        if 'href=' not in tag and 'onclick=' not in tag:
            problems.append((hp, '<a> 缺少 href/onclick'))
    for m in re.finditer(r'<a>(?:\s*)</a>', s):
        problems.append((hp, '空 <a> 标签'))

print('扫描 HTML 文件数: %d' % len(html_files))
if problems:
    for hp, msg in problems:
        print('问题  %s  %s' % (os.path.relpath(hp, ROOT), msg))
    sys.exit(1)
print('全部内部链接与资源引用正常，无僵尸链接。')
