/* ============================================================
   暖心智服 · 静态网站  全局配置文件（唯一需要集中修改的地方）
   ------------------------------------------------------------
   · 网站名称、联系方式、AI 接口、演示模式都在这里配置。
   · 本文件是静态前端文件，【严禁】填写任何密钥、数据库密码。
   · 静态演示版的数据保存在浏览器本地（localStorage），
     换电脑/换浏览器看不到；正式上线请改用随项目附带的 Node 后端。
   ============================================================ */
window.SITE_CONFIG = {

  /* ---------- ① 网站名称（改名只改这里） ---------- */
  name: '暖心智服',
  fullName: '暖心智服——新疆 AI 便民公益服务平台',
  version: '1.0.0（静态版）',

  /* ---------- ② 运行模式 ----------
     demoMode=true ：纯静态演示，申请/工单保存在浏览器本地，AI 为本地知识库检索；
     demoMode=false：需要另行部署后端服务，并填写下面的 apiBase 与 AI 接口。 */
  demoMode: true,
  apiBase: '', // 例如 'https://your-server.example.com'，静态演示版留空

  /* ---------- ③ 联系方式（确认后再填；留空则不显示，不会出现虚假信息） ---------- */
  contact: {
    name: '宋姚雨涵（项目负责人）', // 项目联系人/负责人
    siteDev: '黎华波（网站开发负责人）',
    phone: '',          // 项目办公电话，例如 '0902-XXXXXXX'
    email: '',          // 项目邮箱
    workTime: '',       // 服务时间说明，例如 '工作日 10:00—19:00'
    address: '',        // 联系地址（试点社区：哈密市伊州区青年路西社区）
    wechat_qr: '',      // 微信二维码图片路径，如 'assets/images/wechat.png'
    apply_form_url: ''  // 外部问卷链接（腾讯问卷/问卷星）；填写后申请页可选用外部表单
  },

  /* ---------- ④ 对外公开热线（真实全国统一号码，可直接展示） ---------- */
  hotlines: [
    { name: '政务服务便民热线', number: '12345', desc: '政策咨询、办事指引、诉求反映' },
    { name: '青少年服务台', number: '12355', desc: '青少年心理咨询、法律帮助（以当地开通为准）' },
    { name: '紧急求助', number: '110 / 120 / 119', desc: '人身危险、医疗急救、火灾事故' }
  ],

  /* ---------- ⑤ 试点地区（《项目综述》规划先期 3 个社区，具体名称待确认） ---------- */
  regions: ['乌鲁木齐市', '哈密市', '昌吉回族自治州', '新疆其他地区（请在需求中说明）']
};

/* ============================================================
   业务常量（与《项目综述》服务对象、服务内容、流程保持一致）
   ============================================================ */
window.CONSTANTS = {
  // 公益帮扶申请类型（7 类）
  SERVICE_TYPES: [
    { value: 'disability_home', label: '残疾人居家支持', ug: 'مېيىپلەر ئائىلە ياردىمى' },
    { value: 'home_rehab', label: '居家康复相关支持', ug: 'ئائىلە ساقايتىش ياردىمى' },
    { value: 'daily_care', label: '生活照料或便民协助', ug: 'تۇرمۇش پەرۋىشى ۋە قولايلىق ياردەم' },
    { value: 'left_behind_child', label: '留守儿童及困境儿童关爱', ug: 'ئاتا-ئانىسى يوق ئۆيلەردە قالغان بالىلارغا كۆيۈنۈش' },
    { value: 'autism_family', label: '自闭症儿童家庭支持', ug: 'ئاپتىزملىق بالىلار ئائىلىسىگە ياردەم' },
    { value: 'bilingual_policy', label: '双语政策解读或办事指引', ug: 'قوش تىللىق سىياسەت چۈشەندۈرۈش' },
    { value: 'other', label: '其他公益服务需求', ug: 'باشقا ئىجتىمائىي پاراۋانلىق مۇلازىمىتى' }
  ],

  // 涉及儿童、必须监护人知情同意的类型
  CHILD_TYPES: ['left_behind_child', 'autism_family'],

  // 申请/工单状态（8 步流程对应）
  APP_STATUS: {
    pending:    { label: '待审核', color: '#8a6d1c', dot: '#d9a52e', ug: 'تەكشۈرۈلمىدى' },
    contacting: { label: '联系中', color: '#1d5fa8', dot: '#3a86d6', ug: 'ئالاقىلىشىۋاتىدۇ' },
    planning:   { label: '待安排', color: '#1d5fa8', dot: '#3a86d6', ug: 'ئورۇنلاشتۇرۇلىدۇ' },
    arranged:   { label: '已安排', color: '#0f5c4f', dot: '#1f9c83', ug: 'ئورۇنلاشتۇرۇلدى' },
    serving:    { label: '服务中', color: '#0f5c4f', dot: '#1f9c83', ug: 'مۇلازىمەت قىلىنىۋاتىدۇ' },
    followup:   { label: '待回访', color: '#8a4d1c', dot: '#d9732a', ug: 'قايتا يوقلاش كۈتۈلىدۇ' },
    closed:     { label: '已结案', color: '#3f534d', dot: '#7a8f88', ug: 'تاماملاندى' },
    rejected:   { label: '暂无法处理', color: '#a33a2e', dot: '#c85544', ug: 'بىر تەرەپ قىلغىلى بولمايدۇ' }
  },

  // 状态流转规则（不能跳步）
  STATUS_FLOW: {
    pending:    ['contacting', 'rejected'],
    contacting: ['planning', 'rejected'],
    planning:   ['arranged', 'rejected'],
    arranged:   ['serving', 'rejected'],
    serving:    ['followup', 'rejected'],
    followup:   ['closed', 'serving']
  },

  // 本地便民服务分类
  LOCAL_CATEGORIES: [
    { value: 'gov', label: '政务服务与办事渠道' },
    { value: 'disability', label: '残疾人相关服务' },
    { value: 'child', label: '儿童关爱与未成年人保护' },
    { value: 'community', label: '社区服务' },
    { value: 'charity', label: '公益组织与志愿服务' },
    { value: 'health', label: '康复及健康服务' }
  ],

  // 科普分类
  ARTICLE_CATEGORIES: [
    { value: 'rehab_basic', label: '康复基础知识' },
    { value: 'daily_living', label: '居家活动与日常生活支持' },
    { value: 'elderly', label: '老年人健康与安全' },
    { value: 'disability_care', label: '残疾人家庭照护知识' },
    { value: 'child_growth', label: '儿童成长与家庭支持' },
    { value: 'referral', label: '康复就医与专业服务转介' }
  ],

  // 知识库分类
  KNOWLEDGE_CATEGORIES: [
    { value: 'disability_subsidy', label: '残疾人补贴与福利' },
    { value: 'disability_cert', label: '残疾人证与等级评定' },
    { value: 'child_welfare', label: '儿童关爱与未成年人保护' },
    { value: 'rehab_relief', label: '残疾儿童康复救助' },
    { value: 'social_assistance', label: '社会救助与低保' },
    { value: 'elderly', label: '老年人服务' },
    { value: 'project_service', label: '本平台服务说明' },
    { value: 'other', label: '其他便民政策' }
  ],

  // 后台角色（静态演示版）
  ROLES: {
    admin: { label: '系统管理员' },
    manager: { label: '项目负责人' },
    staff: { label: '服务工作人员' }
  },

  // ===== 第二阶段：运营管理常量 =====

  // 志愿者状态（完成岗前培训且在岗才能参与排班）
  VOLUNTEER_STATUS: {
    active: { label: '在岗', color: '#0f5c4f', dot: '#1f9c83' },
    paused: { label: '暂停服务', color: '#8a6d1c', dot: '#d9a52e' },
    inactive: { label: '已退出', color: '#3f534d', dot: '#7a8f88' }
  },

  // 志愿者专业背景
  VOLUNTEER_MAJORS: [
    { value: 'nursing', label: '护理专业' },
    { value: 'rehab', label: '康复治疗相关专业' },
    { value: 'social', label: '社会工作/心理相关专业' },
    { value: 'other', label: '其他专业' }
  ],

  // 培训类别
  TRAINING_TYPES: [
    { value: 'induction', label: '岗前培训' },
    { value: 'service', label: '服务规范与流程' },
    { value: 'rehab', label: '康复护理技能' },
    { value: 'child', label: '儿童保护与沟通' },
    { value: 'bilingual', label: '汉维双语沟通' },
    { value: 'safety', label: '安全急救（跌倒/急症处置）' }
  ],

  // 培训状态
  TRAINING_STATUS: {
    planned: { label: '计划中', color: '#1d5fa8', dot: '#3a86d6' },
    done: { label: '已完成', color: '#0f5c4f', dot: '#1f9c83' },
    canceled: { label: '已取消', color: '#3f534d', dot: '#7a8f88' }
  },

  // 排班时段
  SCHEDULE_SLOTS: ['上午', '下午', '晚上', '全天'],

  // 排班状态
  SCHEDULE_STATUS: {
    planned: { label: '待服务', color: '#1d5fa8', dot: '#3a86d6' },
    done: { label: '已完成', color: '#0f5c4f', dot: '#1f9c83' },
    canceled: { label: '已取消', color: '#a33a2e', dot: '#c85544' }
  }
};
