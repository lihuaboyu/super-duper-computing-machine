/* ============================================================
   暖心智服 · 静态网站  本地数据层（localStorage）
   ------------------------------------------------------------
   ⚠ 静态演示版说明：
   - 申请、工单、回访、投诉等数据只保存在“当前这台电脑的这个浏览器”里；
   - 居民提交后，工作人员必须在同一浏览器打开后台才能看到，
     这仅用于演示与验收，不能用于真实运营；
   - 后台登录是前端模拟，不具备真正的安全防护；
   - 真实部署请使用随项目提供的 Node 后端（SQLite + 服务端鉴权），
     或把本文件中的方法替换为对服务端 API 的调用。
   ============================================================ */
(function (window) {
  'use strict';

  const KEY = 'nxf_static_db_v1';
  const SESSION_KEY = 'nxf_static_session_v1';

  /* ---------- 基础读写 ---------- */
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* 数据损坏时重建 */ }
    return null;
  }
  function save(db) {
    localStorage.setItem(KEY, JSON.stringify(db));
  }

  function uid(prefix) {
    return prefix + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
  }
  function pad(n) { return String(n).padStart(2, '0'); }
  function todayStr(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function nowStr() {
    const d = new Date();
    return todayStr(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function serviceCode() {
    const d = new Date();
    const ymd = '' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate());
    const rand = Math.floor(1000 + Math.random() * 9000);
    return 'NXF-' + ymd + '-' + rand;
  }

  /* ---------- 初始化（首次使用写入种子数据） ---------- */
  function init() {
    let db = load();
    const S = window.SEED_DATA;
    if (db && db._v === 1) {
      // 第二阶段新增数据集：旧版浏览器存档自动补齐（不覆盖已有数据）
      let migrated = false;
      if (!Array.isArray(db.volunteers)) { db.volunteers = S.volunteers.map(function (v) { return Object.assign({}, v); }); migrated = true; }
      if (!Array.isArray(db.trainings)) { db.trainings = S.trainings.map(function (t) { return Object.assign({}, t); }); migrated = true; }
      if (!Array.isArray(db.schedules)) { db.schedules = []; migrated = true; }
      if (!Array.isArray(db.reminders)) { db.reminders = []; migrated = true; }
      if (migrated) save(db);
      return db;
    }
    db = {
      _v: 1,
      users: S.users.map(function (u) { return Object.assign({}, u); }),
      applications: [],
      orders: [],
      followups: [],
      complaints: [],
      feedback: [],
      qaLogs: [],
      auditLogs: [],
      volunteers: S.volunteers.map(function (v) { return Object.assign({}, v); }),
      trainings: S.trainings.map(function (t) { return Object.assign({}, t); }),
      schedules: [],
      reminders: [],
      knowledge: S.knowledge.map(function (k) { return Object.assign({}, k); }),
      localServices: S.localServices.map(function (l) { return Object.assign({}, l); }),
      articles: S.articles.map(function (a) { return Object.assign({}, a); })
    };
    save(db);
    return db;
  }

  function mut(fn) {
    const db = init();
    const r = fn(db);
    save(db);
    return r;
  }

  /* ---------- 审计日志 ---------- */
  function log(action, target) {
    const session = currentUser();
    mut(function (db) {
      db.auditLogs.unshift({
        id: uid('LOG'), at: nowStr(),
        actor: session ? session.username : '居民',
        role: session ? session.role : 'public',
        action: action, target: target || ''
      });
      if (db.auditLogs.length > 500) db.auditLogs.length = 500;
    });
  }

  /* ---------- 后台会话（静态演示版，仅存 sessionStorage） ---------- */
  function login(username, password) {
    const db = init();
    const u = db.users.find(function (x) { return x.username === username.trim() && x.password === password; });
    if (!u) return { ok: false, msg: '账号或密码不正确' };
    const session = { username: u.username, realName: u.realName, role: u.role, at: nowStr() };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    log('登录后台', u.username);
    return { ok: true, user: session };
  }
  function logout() {
    log('退出后台', '');
    sessionStorage.removeItem(SESSION_KEY);
  }
  function currentUser() {
    try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); }
    catch (e) { return null; }
  }
  function requireRole(roles) {
    const u = currentUser();
    if (!u) return null;
    if (roles && roles.indexOf(u.role) === -1) return false;
    return u;
  }

  /* ---------- 政策知识库 ---------- */
  function knowledgeList(includeDraft) {
    return init().knowledge.filter(function (k) { return includeDraft ? true : k.status === 'approved'; });
  }
  function knowledgeSave(item) {
    return mut(function (db) {
      const i = db.knowledge.findIndex(function (k) { return k.id === item.id; });
      if (i >= 0) {
        db.knowledge[i] = Object.assign(db.knowledge[i], item);
        log('编辑知识库', item.id + ' ' + item.title);
      } else {
        item.id = item.id || uid('K');
        item.version = 1;
        db.knowledge.unshift(item);
        log('新增知识库', item.id + ' ' + item.title);
      }
      return item;
    });
  }
  function knowledgeSetStatus(id, status) {
    return mut(function (db) {
      const k = db.knowledge.find(function (x) { return x.id === id; });
      if (k) { k.status = status; if (status === 'approved' && !k.verifiedAt) k.verifiedAt = todayStr(); log('知识库状态变更', id + ' → ' + status); }
      return k;
    });
  }

  /* ---------- 本地便民信息 ---------- */
  function localList(showDemo) {
    return init().localServices.filter(function (l) { return showDemo || l.status !== 'demo'; });
  }
  function localSave(item) {
    return mut(function (db) {
      const i = db.localServices.findIndex(function (l) { return l.id === item.id; });
      if (i >= 0) { db.localServices[i] = Object.assign(db.localServices[i], item); log('编辑便民信息', item.id); }
      else { item.id = item.id || uid('L'); db.localServices.unshift(item); log('新增便民信息', item.id + ' ' + item.name); }
      return item;
    });
  }

  /* ---------- 科普文章 ---------- */
  function articleList(includeDraft) {
    return init().articles.filter(function (a) { return includeDraft ? true : a.status === 'approved'; });
  }
  function articleSave(item) {
    return mut(function (db) {
      const i = db.articles.findIndex(function (a) { return a.id === item.id; });
      if (i >= 0) { db.articles[i] = Object.assign(db.articles[i], item); log('编辑科普文章', item.id); }
      else { item.id = item.id || uid('A'); item.updatedAt = todayStr(); db.articles.unshift(item); log('新增科普文章', item.id + ' ' + item.title); }
      return item;
    });
  }
  function articleSetStatus(id, status, reviewedBy) {
    return mut(function (db) {
      const a = db.articles.find(function (x) { return x.id === id; });
      if (a) { a.status = status; a.reviewedBy = reviewedBy || a.reviewedBy || ''; a.updatedAt = todayStr(); log('科普文章状态变更', id + ' → ' + status); }
      return a;
    });
  }

  /* ---------- 公益帮扶申请 ---------- */
  function createApplication(form) {
    // 基本校验
    if (!form || !form.type || !form.region || !form.phone || !form.need) {
      return { ok: false, msg: '请完整填写服务类型、所在地区、联系方式和需求简述' };
    }
    if (!/^[0-9+\-\s]{6,20}$/.test(form.phone.replace(/\s/g, ''))) {
      return { ok: false, msg: '联系电话格式似乎不正确，请检查' };
    }
    if (window.CONSTANTS.CHILD_TYPES.indexOf(form.type) >= 0 && !form.guardianConsent) {
      return { ok: false, msg: '涉及儿童的服务必须填写监护人称呼并勾选“监护人已知情同意”' };
    }
    if (!form.authConsent) {
      return { ok: false, msg: '请阅读并勾选个人信息授权确认后再提交' };
    }
    const app = {
      id: uid('APP'),
      code: serviceCode(),
      type: form.type,
      region: form.region,
      regionDetail: form.regionDetail || '',
      need: form.need,
      contactName: form.contactName || '',
      phone: form.phone.replace(/\s/g, ''),
      contactTime: form.contactTime || '',
      guardianName: form.guardianName || '',
      guardianConsent: !!form.guardianConsent,
      authConsent: true,
      status: 'pending',
      internalNote: '',
      contactLog: [],
      createdAt: nowStr(),
      updatedAt: nowStr()
    };
    mut(function (db) {
      db.applications.unshift(app);
      db.auditLogs.unshift({ id: uid('LOG'), at: nowStr(), actor: '居民', role: 'public', action: '提交公益申请', target: app.code });
    });
    return { ok: true, code: app.code, app: app };
  }
  function applicationList() { return init().applications; }
  function getApplication(id) { return init().applications.find(function (a) { return a.id === id; }); }
  function findByCodeAndPhone(code, phone) {
    return init().applications.find(function (a) {
      return a.code.toUpperCase() === code.trim().toUpperCase() && a.phone === phone.replace(/\s/g, '');
    });
  }
  function statusLabel(s) { return (window.CONSTANTS.APP_STATUS[s] || { label: s }).label; }

  function setApplicationStatus(id, next, extra) {
    return mut(function (db) {
      const a = db.applications.find(function (x) { return x.id === id; });
      if (!a) return { ok: false, msg: '申请不存在' };
      const allowed = window.CONSTANTS.STATUS_FLOW[a.status] || [];
      if (allowed.indexOf(next) === -1) {
        return { ok: false, msg: '当前状态（' + statusLabel(a.status) + '）不能直接变更为“' + statusLabel(next) + '”' };
      }
      if (next === 'rejected' && !(extra && extra.reason)) {
        return { ok: false, msg: '标记“暂无法处理”必须填写原因和转介建议' };
      }
      a.status = next;
      a.updatedAt = nowStr();
      if (extra) {
        if (extra.note) a.internalNote = extra.note;
        if (extra.reason) a.rejectReason = extra.reason;
      }
      log('申请状态变更', a.code + ' → ' + statusLabel(next));
      return { ok: true, app: a };
    });
  }
  function addContactLog(id, text) {
    return mut(function (db) {
      const a = db.applications.find(function (x) { return x.id === id; });
      if (!a || !text) return { ok: false, msg: '记录内容为空' };
      a.contactLog.push({ at: nowStr(), text: text, by: (currentUser() || {}).username || '工作人员' });
      a.updatedAt = nowStr();
      log('记录联系情况', a.code);
      return { ok: true, app: a };
    });
  }
  function saveInternalNote(id, note) {
    return mut(function (db) {
      const a = db.applications.find(function (x) { return x.id === id; });
      if (!a) return { ok: false, msg: '申请不存在' };
      a.internalNote = note; a.updatedAt = nowStr();
      log('更新内部备注', a.code);
      return { ok: true, app: a };
    });
  }

  /* ---------- 服务工单 ---------- */
  function createOrder(applicationId, owner, plannedAt) {
    return mut(function (db) {
      const a = db.applications.find(function (x) { return x.id === applicationId; });
      if (!a) return { ok: false, msg: '申请不存在' };
      const order = {
        id: uid('ORD'), code: 'GD-' + a.code.slice(4),
        applicationId: applicationId, appCode: a.code,
        owner: owner || '', plannedAt: plannedAt || '',
        serviceType: a.type, progress: '',
        records: [], status: 'arranged',
        rejectReason: '', referral: '',
        createdAt: nowStr(), updatedAt: nowStr()
      };
      db.orders.unshift(order);
      a.status = 'arranged'; a.updatedAt = nowStr();
      log('创建工单并派单', order.code + ' 负责人：' + (owner || '未指定'));
      return { ok: true, order: order };
    });
  }
  function orderList() { return init().orders; }
  function updateOrder(id, patch) {
    return mut(function (db) {
      const o = db.orders.find(function (x) { return x.id === id; });
      if (!o) return { ok: false, msg: '工单不存在' };
      ['owner', 'plannedAt', 'progress', 'rejectReason', 'referral'].forEach(function (k) {
        if (patch[k] !== undefined) o[k] = patch[k];
      });
      if (patch.status) {
        const orderFlow = ['arranged', 'serving', 'followup', 'closed'];
        if (patch.status === 'rejected' && !patch.rejectReason) return { ok: false, msg: '暂无法处理必须填写原因' };
        o.status = patch.status;
        const a = db.applications.find(function (x) { return x.id === o.applicationId; });
        if (a) { a.status = patch.status; a.updatedAt = nowStr(); if (patch.rejectReason) a.rejectReason = patch.rejectReason; }
      }
      o.updatedAt = nowStr();
      log('更新工单', o.code + ' ' + (patch.status || '信息'));
      return { ok: true, order: o };
    });
  }
  function addOrderRecord(id, text) {
    return mut(function (db) {
      const o = db.orders.find(function (x) { return x.id === id; });
      if (!o || !text) return { ok: false, msg: '服务记录为空' };
      o.records.push({ at: nowStr(), text: text, by: (currentUser() || {}).username || '工作人员' });
      o.updatedAt = nowStr();
      const a = db.applications.find(function (x) { return x.id === o.applicationId; });
      if (a) { a.status = 'serving'; a.updatedAt = nowStr(); }
      o.status = 'serving';
      log('填写服务记录', o.code);
      return { ok: true, order: o };
    });
  }

  /* ---------- 回访与投诉 ---------- */
  function addFollowup(appCode, method, satisfaction, content) {
    return mut(function (db) {
      const f = {
        id: uid('FU'), appCode: appCode || '', method: method || '电话回访',
        satisfaction: satisfaction || '', content: content || '',
        at: nowStr(), by: (currentUser() || {}).username || '工作人员'
      };
      db.followups.unshift(f);
      const a = db.applications.find(function (x) { return x.code === appCode; });
      if (a) { a.status = 'followup'; a.updatedAt = nowStr(); }
      const o = db.orders.find(function (x) { return x.appCode === appCode; });
      if (o) { o.status = 'followup'; o.updatedAt = nowStr(); }
      log('登记回访', appCode);
      return { ok: true, item: f };
    });
  }
  function followupList() { return init().followups; }
  function closeCase(appCode, summary) {
    return mut(function (db) {
      const a = db.applications.find(function (x) { return x.code === appCode; });
      if (!a) return { ok: false, msg: '申请不存在' };
      if (['followup', 'serving'].indexOf(a.status) === -1) return { ok: false, msg: '只有服务中/待回访的工单可以结案' };
      a.status = 'closed'; a.closeSummary = summary || ''; a.updatedAt = nowStr();
      const o = db.orders.find(function (x) { return x.appCode === appCode; });
      if (o) { o.status = 'closed'; o.updatedAt = nowStr(); }
      log('结案', appCode);
      return { ok: true, app: a };
    });
  }
  function addComplaint(item) {
    return mut(function (db) {
      const c = Object.assign({
        id: uid('TS'), appCode: '', channel: '电话',
        content: '', status: '登记', handling: '', rectify: '', revisit: '', result: '',
        at: nowStr(), by: (currentUser() || {}).username || '工作人员'
      }, item);
      db.complaints.unshift(c);
      log('登记投诉', c.id + ' ' + c.appCode);
      return { ok: true, item: c };
    });
  }
  function complaintList() { return init().complaints; }
  function updateComplaint(id, patch) {
    return mut(function (db) {
      const c = db.complaints.find(function (x) { return x.id === id; });
      if (!c) return { ok: false, msg: '投诉不存在' };
      Object.assign(c, patch);
      log('更新投诉处理', id + ' → ' + c.status);
      return { ok: true, item: c };
    });
  }

  /* ---------- 意见反馈（前台） ---------- */
  function addFeedback(type, content, contact) {
    if (!content || content.trim().length < 5) return { ok: false, msg: '请填写反馈内容（至少 5 个字）' };
    return mut(function (db) {
      const f = { id: uid('FB'), type: type || '其他', content: content, contact: contact || '', at: nowStr() };
      db.feedback.unshift(f);
      return { ok: true, item: f };
    });
  }
  function feedbackList() { return init().feedback; }

  /* ---------- AI 问答质量日志（匿名） ---------- */
  function logQA(q, matched, kind) {
    mut(function (db) {
      db.qaLogs.unshift({
        id: uid('QA'), q: String(q).slice(0, 120),
        matched: !!matched, kind: kind || 'normal', at: nowStr()
      });
      if (db.qaLogs.length > 300) db.qaLogs.length = 300;
    });
  }
  function qaLogs() { return init().qaLogs; }

  /* ============================================================
     第二阶段：志愿者 / 培训 / 排班 / 回访提醒 / 统计报表
     ============================================================ */

  /* ---------- 志愿者 ---------- */
  function volunteerList() { return init().volunteers; }
  function volunteerSave(item) {
    if (!item || !item.name || !String(item.name).trim()) return { ok: false, msg: '请填写志愿者称呼' };
    return mut(function (db) {
      const i = db.volunteers.findIndex(function (v) { return v.id === item.id; });
      if (i >= 0) {
        db.volunteers[i] = Object.assign(db.volunteers[i], item);
        log('编辑志愿者', item.id + ' ' + item.name);
        return { ok: true, item: db.volunteers[i] };
      }
      item.id = item.id || uid('V');
      item.joinedAt = item.joinedAt || todayStr();
      item.serviceHours = Number(item.serviceHours) || 0;
      item.status = item.status || 'active';
      db.volunteers.unshift(item);
      log('新增志愿者', item.id + ' ' + item.name);
      return { ok: true, item: item };
    });
  }
  function volunteerSetStatus(id, status) {
    return mut(function (db) {
      const v = db.volunteers.find(function (x) { return x.id === id; });
      if (v) { v.status = status; log('志愿者状态变更', id + ' → ' + status); }
      return v;
    });
  }

  /* ---------- 培训记录 ---------- */
  function trainingList() { return init().trainings; }
  function trainingSave(item) {
    if (!item || !item.title || !String(item.title).trim()) return { ok: false, msg: '请填写培训主题' };
    return mut(function (db) {
      const i = db.trainings.findIndex(function (t) { return t.id === item.id; });
      if (i >= 0) {
        db.trainings[i] = Object.assign(db.trainings[i], item);
        log('编辑培训记录', item.id + ' ' + item.title);
        return { ok: true, item: db.trainings[i] };
      }
      item.id = item.id || uid('T');
      item.status = item.status || 'planned';
      item.hours = Number(item.hours) || 0;
      item.attendees = Number(item.attendees) || 0;
      item.createdAt = nowStr();
      db.trainings.unshift(item);
      log('新增培训记录', item.id + ' ' + item.title);
      return { ok: true, item: item };
    });
  }
  function trainingSetStatus(id, status) {
    return mut(function (db) {
      const t = db.trainings.find(function (x) { return x.id === id; });
      if (t) { t.status = status; if (status === 'done' && !t.date) t.date = todayStr(); log('培训状态变更', id + ' → ' + status); }
      return t;
    });
  }

  /* ---------- 服务排班 ---------- */
  function scheduleList() {
    return init().schedules.slice().sort(function (a, b) {
      return (a.date + ' ' + (a.slot || '')).localeCompare(b.date + ' ' + (b.slot || ''));
    });
  }
  function scheduleCreate(item) {
    if (!item || !item.date) return { ok: false, msg: '请选择排班日期' };
    if (!item.volunteerName) return { ok: false, msg: '请指定参与服务的志愿者/工作人员' };
    return mut(function (db) {
      const sc = {
        id: uid('PB'), appCode: item.appCode || '', date: item.date, slot: item.slot || '上午',
        volunteerName: item.volunteerName, serviceType: item.serviceType || '',
        hours: Number(item.hours) || 0, note: item.note || '',
        status: 'planned', hoursAdded: false, createdAt: nowStr()
      };
      db.schedules.unshift(sc);
      log('新增排班', sc.date + ' ' + sc.volunteerName);
      return { ok: true, item: sc };
    });
  }
  function scheduleUpdate(id, patch) {
    return mut(function (db) {
      const sc = db.schedules.find(function (x) { return x.id === id; });
      if (!sc) return { ok: false, msg: '排班不存在' };
      if (patch.status) {
        if (patch.status === 'done' && !sc.hoursAdded && sc.hours) {
          // 完成时把服务时长计入对应志愿者（仅计一次）
          const v = db.volunteers.find(function (x) { return x.name === sc.volunteerName; });
          if (v) { v.serviceHours = (Number(v.serviceHours) || 0) + Number(sc.hours); }
          sc.hoursAdded = true;
        }
        sc.status = patch.status;
      }
      if (patch.note !== undefined) sc.note = patch.note;
      log('排班状态变更', sc.id + ' → ' + (patch.status || '更新'));
      return { ok: true, item: sc };
    });
  }
  function scheduleDelete(id) {
    return mut(function (db) {
      const i = db.schedules.findIndex(function (x) { return x.id === id; });
      if (i >= 0) { const sc = db.schedules.splice(i, 1)[0]; log('删除排班', sc.id); }
      return { ok: true };
    });
  }

  /* ---------- 回访提醒 ---------- */
  function dateOnly(s) { return String(s || '').slice(0, 10); }
  function daysBetween(a, b) {
    const da = new Date(a + 'T00:00:00');
    const db2 = new Date(b + 'T00:00:00');
    if (isNaN(da.getTime()) || isNaN(db2.getTime())) return null;
    return Math.round((db2.getTime() - da.getTime()) / 86400000);
  }
  function reminderCreate(item) {
    if (!item || !item.dueDate) return { ok: false, msg: '请选择提醒日期' };
    if (!item.content || !item.content.trim()) return { ok: false, msg: '请填写提醒事项' };
    return mut(function (db) {
      const r = {
        id: uid('RM'), appCode: item.appCode || '', dueDate: item.dueDate,
        content: item.content, done: false, at: nowStr(), by: (currentUser() || {}).username || '工作人员'
      };
      db.reminders.unshift(r);
      log('新增回访提醒', r.appCode || r.dueDate);
      return { ok: true, item: r };
    });
  }
  function reminderDone(id) {
    return mut(function (db) {
      const r = db.reminders.find(function (x) { return x.id === id; });
      if (r) { r.done = true; log('完成提醒', r.id); }
      return { ok: true };
    });
  }
  function reminderDelete(id) {
    return mut(function (db) {
      const i = db.reminders.findIndex(function (x) { return x.id === id; });
      if (i >= 0) db.reminders.splice(i, 1);
      return { ok: true };
    });
  }
  // 显式提醒 + 系统派生（服务中 3 天未回访、回访后 2 天未结案），按到期日排序
  function reminderList() {
    const d = init();
    const today = todayStr();
    const out = [];
    d.reminders.forEach(function (r) {
      out.push({
        id: r.id, kind: 'manual', appCode: r.appCode, dueDate: r.dueDate,
        content: r.content, done: r.done,
        overdue: !r.done && daysBetween(r.dueDate, today) > 0
      });
    });
    d.orders.forEach(function (o) {
      let base = '', due = '', content = '';
      if (o.status === 'serving') {
        const last = o.records && o.records.length ? o.records[o.records.length - 1].at : o.createdAt;
        base = dateOnly(last);
        const d2 = new Date(base + 'T00:00:00');
        if (!isNaN(d2.getTime())) { d2.setDate(d2.getDate() + 3); due = todayStr(d2); }
        content = '服务进行中：自最近一次服务已 3 天，请及时回访（' + o.appCode + '）';
      } else if (o.status === 'followup') {
        const f = d.followups.filter(function (x) { return x.appCode === o.appCode; }).sort(function (a, b) {
          return a.at < b.at ? 1 : -1;
        })[0];
        base = f ? dateOnly(f.at) : dateOnly(o.updatedAt);
        const d2 = new Date(base + 'T00:00:00');
        if (!isNaN(d2.getTime())) { d2.setDate(d2.getDate() + 2); due = todayStr(d2); }
        content = '回访已登记：请在 2 天内完成复评并结案（' + o.appCode + '）';
      }
      if (due) {
        const gap = daysBetween(due, today);
        out.push({
          id: 'auto-' + o.id, kind: 'auto', appCode: o.appCode, dueDate: due,
          content: content, done: false, overdue: gap !== null && gap > 0
        });
      }
    });
    return out.sort(function (a, b) {
      if (a.done !== b.done) return a.done ? 1 : -1;
      return a.dueDate.localeCompare(b.dueDate);
    });
  }

  /* ---------- AI 问答质量统计 ---------- */
  function qaStats() {
    const logs = init().qaLogs;
    const emergency = logs.filter(function (l) { return l.kind === 'emergency'; }).length;
    const normal = logs.filter(function (l) { return l.kind !== 'emergency'; });
    const matched = normal.filter(function (l) { return l.matched; }).length;
    const unmatched = normal.filter(function (l) { return !l.matched; });
    const freq = {};
    unmatched.forEach(function (l) {
      const q = l.q.replace(/\s/g, '').slice(0, 30);
      if (!freq[q]) freq[q] = { q: l.q, count: 0, lastAt: l.at };
      freq[q].count++;
      if (l.at > freq[q].lastAt) freq[q].lastAt = l.at;
    });
    const topUnmatched = Object.keys(freq).map(function (k) { return freq[k]; })
      .sort(function (a, b) { return b.count - a.count; }).slice(0, 10);
    return {
      total: logs.length,
      emergency: emergency,
      normalTotal: normal.length,
      matched: matched,
      unmatched: unmatched.length,
      hitRate: normal.length ? Math.round(matched / normal.length * 100) : null,
      topUnmatched: topUnmatched
    };
  }

  /* ---------- 项目统计报表（全部来自真实记录，不编造） ---------- */
  function reportData() {
    const d = init();
    const monthKey = function (s) { return String(s || '').slice(0, 7); };
    const monthLabel = function (k) {
      const p = (k || '').split('-');
      return p.length === 2 ? (Number(p[1]) + '月') : '';
    };
    // 近 6 个月
    const months = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const dt = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push(dt.getFullYear() + '-' + pad(dt.getMonth() + 1));
    }
    const blank = function () { const o = {}; months.forEach(function (m) { o[m] = 0; }); return o; };
    const appByMonth = blank(), orderByMonth = blank(), closedByMonth = blank();
    d.applications.forEach(function (a) {
      const m = monthKey(a.createdAt); if (appByMonth[m] !== undefined) appByMonth[m]++;
      if (a.status === 'closed') { const cm = monthKey(a.updatedAt); if (closedByMonth[cm] !== undefined) closedByMonth[cm]++; }
    });
    d.orders.forEach(function (o) {
      const m = monthKey(o.createdAt); if (orderByMonth[m] !== undefined) orderByMonth[m]++;
    });
    // 按类型
    const byType = {};
    window.CONSTANTS.SERVICE_TYPES.forEach(function (t) { byType[t.value] = 0; });
    d.applications.forEach(function (a) { if (byType[a.type] !== undefined) byType[a.type]++; });
    // 满意度
    const sat = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    let satTotal = 0;
    d.followups.forEach(function (f) {
      if (f.satisfaction && sat[f.satisfaction] !== undefined) { sat[f.satisfaction]++; satTotal += Number(f.satisfaction); }
    });
    // 志愿者/培训/排班
    const activeVolunteers = d.volunteers.filter(function (v) { return v.status === 'active'; }).length;
    const trainedVolunteers = d.volunteers.filter(function (v) { return v.trained; }).length;
    const volunteerHours = d.volunteers.reduce(function (sum, v) { return sum + (Number(v.serviceHours) || 0); }, 0);
    const trainingsDone = d.trainings.filter(function (t) { return t.status === 'done'; }).length;
    const trainingsPlanned = d.trainings.filter(function (t) { return t.status === 'planned'; }).length;
    const trainingHours = d.trainings.filter(function (t) { return t.status === 'done'; })
      .reduce(function (sum, t) { return sum + (Number(t.hours) || 0); }, 0);
    const sc = { planned: 0, done: 0, canceled: 0 };
    d.schedules.forEach(function (s) { if (sc[s.status] !== undefined) sc[s.status]++; });
    return {
      months: months.map(function (m) { return { key: m, label: monthLabel(m) }; }),
      appByMonth: appByMonth, orderByMonth: orderByMonth, closedByMonth: closedByMonth,
      byType: byType,
      satisfaction: { dist: sat, avg: d.followups.length ? Math.round(satTotal / d.followups.length * 10) / 10 : null },
      qa: qaStats(),
      volunteers: { total: d.volunteers.length, active: activeVolunteers, trained: trainedVolunteers, hours: volunteerHours },
      trainings: { total: d.trainings.length, done: trainingsDone, planned: trainingsPlanned, hours: trainingHours },
      schedules: sc,
      complaints: { total: d.complaints.length, open: d.complaints.filter(function (c) { return c.status !== '办结'; }).length }
    };
  }

  /* ---------- 统计（全部来自真实记录） ---------- */
  function stats() {
    const db = init();
    const s = {
      pending: 0, contacting: 0, planning: 0, arranged: 0, serving: 0, followup: 0, closed: 0, rejected: 0,
      total: db.applications.length,
      orders: db.orders.length,
      followups: db.followups.length,
      complaintsOpen: db.complaints.filter(function (c) { return c.status !== '办结'; }).length,
      complaintsTotal: db.complaints.length,
      knowledgeApproved: db.knowledge.filter(function (k) { return k.status === 'approved'; }).length,
      knowledgeDraft: db.knowledge.filter(function (k) { return k.status === 'draft'; }).length
    };
    db.applications.forEach(function (a) { s[a.status] = (s[a.status] || 0) + 1; });
    return s;
  }

  function auditLogs() { return init().auditLogs; }

  /* ---------- 本地数据重置（恢复初始种子） ---------- */
  function resetDemo() {
    localStorage.removeItem(KEY);
    init();
    log('重置本地数据', '');
  }

  window.Store = {
    init: init, log: log,
    login: login, logout: logout, currentUser: currentUser, requireRole: requireRole,
    knowledgeList: knowledgeList, knowledgeSave: knowledgeSave, knowledgeSetStatus: knowledgeSetStatus,
    localList: localList, localSave: localSave,
    articleList: articleList, articleSave: articleSave, articleSetStatus: articleSetStatus,
    createApplication: createApplication, applicationList: applicationList, getApplication: getApplication,
    findByCodeAndPhone: findByCodeAndPhone, setApplicationStatus: setApplicationStatus,
    addContactLog: addContactLog, saveInternalNote: saveInternalNote,
    createOrder: createOrder, orderList: orderList, updateOrder: updateOrder, addOrderRecord: addOrderRecord,
    addFollowup: addFollowup, followupList: followupList, closeCase: closeCase,
    addComplaint: addComplaint, complaintList: complaintList, updateComplaint: updateComplaint,
    addFeedback: addFeedback, feedbackList: feedbackList,
    logQA: logQA, qaLogs: qaLogs, qaStats: qaStats,
    volunteerList: volunteerList, volunteerSave: volunteerSave, volunteerSetStatus: volunteerSetStatus,
    trainingList: trainingList, trainingSave: trainingSave, trainingSetStatus: trainingSetStatus,
    scheduleList: scheduleList, scheduleCreate: scheduleCreate, scheduleUpdate: scheduleUpdate, scheduleDelete: scheduleDelete,
    reminderCreate: reminderCreate, reminderDone: reminderDone, reminderDelete: reminderDelete, reminderList: reminderList,
    reportData: reportData,
    stats: stats, auditLogs: auditLogs, resetDemo: resetDemo,
    todayStr: todayStr, nowStr: nowStr
  };
})(window);
